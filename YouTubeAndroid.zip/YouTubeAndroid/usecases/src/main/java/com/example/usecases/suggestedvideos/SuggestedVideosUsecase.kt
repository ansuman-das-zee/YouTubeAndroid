package com.example.usecases.suggestedvideos

import com.example.domain.entities.search.SearchDataClass
import com.example.usecases.base.BaseUsecase


interface SuggestedVideosUsecase : BaseUsecase<SuggestedVideosUsecase.Input,Result<SearchDataClass>>{
    data class Input(val queryParam : String?=null,
                     val searchVideoPart:String?=null,
                     val regCode: String?=null,
                     val noOfResults: String?=null,
                     val orderString: String?=null)
}