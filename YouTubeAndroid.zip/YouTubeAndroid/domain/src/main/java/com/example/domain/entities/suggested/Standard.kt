package com.example.domain.entities.suggested

data class Standard(
    val height: Int,
    val url: String,
    val width: Int
)