package com.example.domain.entities.suggested

data class High(
    val height: Int,
    val url: String,
    val width: Int
)