package com.example.domain.entities.search

data class High(
    val height: Int,
    val url: String,
    val width: Int
)