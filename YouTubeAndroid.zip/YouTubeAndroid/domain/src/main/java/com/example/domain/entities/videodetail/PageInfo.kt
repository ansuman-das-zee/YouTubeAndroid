package com.example.domain.entities.videodetail

data class PageInfo(
    val resultsPerPage: Int,
    val totalResults: Int
)