package com.example.domain.entities.search

data class Id(
    val kind: String,
    val videoId: String
)