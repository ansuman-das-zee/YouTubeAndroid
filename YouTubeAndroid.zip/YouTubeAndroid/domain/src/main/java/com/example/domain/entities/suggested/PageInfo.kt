package com.example.domain.entities.suggested

data class PageInfo(
    val resultsPerPage: Int,
    val totalResults: Int
)