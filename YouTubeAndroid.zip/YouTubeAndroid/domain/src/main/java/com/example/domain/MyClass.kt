package com.example.domain

class MyClass {
}