package com.example.domain.repositories

import com.example.domain.entities.videodetail.VideoDetailDataClass

class VideoDetailRepository {

//    suspend fun playVideo(videoDetails: VideoDetailDataClass):Result<>
}