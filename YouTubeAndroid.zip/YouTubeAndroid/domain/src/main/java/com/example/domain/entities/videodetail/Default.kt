package com.example.domain.entities.videodetail

data class Default(
    val height: Int,
    val url: String,
    val width: Int
)