package com.example.domain.entities.search

data class Default(
    val height: Int,
    val url: String,
    val width: Int
)