package com.example.domain.entities.suggested

data class Medium(
    val height: Int,
    val url: String,
    val width: Int
)