package com.example.domain.entities.videodetail

data class Medium(
    val height: Int,
    val url: String,
    val width: Int
)