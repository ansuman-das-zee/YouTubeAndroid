package com.example.domain.entities.videodetail

data class Maxres(
    val height: Int,
    val url: String,
    val width: Int
)