package com.example.domain.entities.videodetail

data class High(
    val height: Int,
    val url: String,
    val width: Int
)