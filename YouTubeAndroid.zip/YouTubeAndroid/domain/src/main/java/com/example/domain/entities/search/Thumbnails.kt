package com.example.domain.entities.search

data class Thumbnails(
    val default: com.example.domain.entities.search.Default,
    val high: com.example.domain.entities.search.High,
    val medium: com.example.domain.entities.search.Medium
)