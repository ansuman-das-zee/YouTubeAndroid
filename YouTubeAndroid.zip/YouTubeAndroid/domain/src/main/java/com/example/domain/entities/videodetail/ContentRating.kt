package com.example.domain.entities.videodetail

class ContentRating