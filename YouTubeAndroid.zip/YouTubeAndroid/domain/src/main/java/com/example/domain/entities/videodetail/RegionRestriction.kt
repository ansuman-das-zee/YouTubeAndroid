package com.example.domain.entities.videodetail

data class RegionRestriction(
    val blocked: List<String>
)