package com.example.domain.repositories

import com.example.domain.entities.search.SearchDataClass
import com.example.domain.entities.search.SearchQuery
import retrofit2.Response

//interface searchResponseRepository {
//    suspend fun getSuggestedVideos(SearchQuery(
//    input.queryParam,
//    input.searchVideoPar,
//    input.regCode,
//    input.noOfResults,
//    input.orderString
//    )): Result<SearchDataClass>
//}

interface SearchResponseRepository {
    suspend fun getSuggestedVideos(searchquery: SearchQuery): Result<SearchDataClass>
}