package com.example.domain.entities.suggested

data class Id(
    val kind: String,
    val videoId: String
)