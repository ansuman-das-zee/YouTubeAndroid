package com.example.domain.entities.videodetail

data class Standard(
    val height: Int,
    val url: String,
    val width: Int
)