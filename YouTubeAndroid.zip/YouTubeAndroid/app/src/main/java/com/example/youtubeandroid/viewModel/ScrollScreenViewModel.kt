package com.example.youtubeandroid.viewModel

import android.util.Log
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.usecases.suggestedvideos.SuggestedVideosUsecase
import com.example.youtubeandroid.event.Event
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch


class ScrollScreenViewModel(private val sugVideos:SuggestedVideosUsecase) : ViewModel(){
    private val _state = mutableStateOf(ViewState())
    val state :  State<ViewState> = _state
    private var getVideosJob: Job? = null

//    fun onState(appState : ViewState){
//        when(appState.isVideoDetailsPage){
//            true -> {
//
//            }
//            else -> {
//
//
//            }
//        }
//    }

    init {

        startScreen()

    }
    fun onEvent( appEvent: Event){
        when(appEvent){
            is Event.playButtonClick -> {
                viewModelScope.launch{
//                    sugVideos.exec(appEvent.id)
                    Log.e("Print","PlayButtonClick")
                }
            }

            is Event.backButtonClick -> {
                viewModelScope.launch{
                    Log.e("Print","backButton click")
                }
            }


        }
    }
    fun testViewmodel() : String{
        viewModelScope.launch{
            Log.e("Print","The view model functions are working")

        }

        val s : String = "Viewmodel started"
        return s

    }
    fun startScreen(){
        val searchQuery = SuggestedVideosUsecase.Input(
            "New",
            "snippet,id",
            "US",
            "20",
            "date"
        )
        getVideosJob?.cancel()

//
//
        viewModelScope.launch{
//            val
//            val s : Result<SearchDataClass> = sugVideos.exec(searchQuery).map { response ->
//                SearchDataClass(
//                    items = response.items.map { item ->
//                        Item(
//                            id = item.id,
//                            kind = item.kind,
//                            snippet = item.snippet
//                        )
//
//                    },
//                    kind = response.kind,
//                    nextPageToken = response.nextPageToken,
//                    pageInfo = response.pageInfo,
//                    regionCode = response.regionCode
//                )
//            }
            val st : String = sugVideos.exec(searchQuery).toString()
            val rr = sugVideos.exec(searchQuery)
            Log.e("Newlog",st)



        }



//            .map {
//            vid ->
//                _state.value = state.value.copy(
//
//                )
//        }
    }
}