package com.example.youtubeandroid

import com.example.domain.repositories.SearchResponseRepository


class YoutubeService(private val searchResponseRepository : SearchResponseRepository) {

}