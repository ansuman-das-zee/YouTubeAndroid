package com.example.youtubeandroid

import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ComposeCompilerApi
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import com.example.data.network.api.VideoApiService
import com.example.youtubeandroid.event.Event
import com.example.youtubeandroid.player.Player
import com.example.youtubeandroid.player.PlayerImpl
import com.example.youtubeandroid.ui.theme.YouTubeAndroidTheme

import org.koin.androidx.viewmodel.ext.android.sharedViewModel
import com.example.youtubeandroid.viewModel.ScrollScreenViewModel
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

//exoploplayer
//import com.google.android.exoplayer2.ExoPlayer
//import com.google.android.exoplayer2.source.ProgressiveMediaSource
//import com.google.android.exoplayer2.ui.PlayerView
//import com.google.android.exoplayer2.upstream.DefaultDataSource
//import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
//import com.google.android.exoplayer2.util.Util

class MainActivity : ComponentActivity() {

    private var youtubePlayer : Player = PlayerImpl()
//    private val api by inject<VideoApiService> ()
    //using by to get tge getters and setters
//    private val viewModel : ScrollScreenViewModel by viewModels()
    private val viewModel by inject<ScrollScreenViewModel>()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        getMyData()


        setContent {



            YouTubeAndroidTheme {

                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
//                    Greeting("Android")
                    RecyclerItems()


                    viewModel.startScreen()
                    Log.e("New","App is working")
//                    val lists = listOf<String>("31","23","34","sebam")
//                    val lists = listOf()
                    RecyclerItems()

//                    viewModel.onEvent(Event.playButtonClick)



//                    ListItem(name = "1")


                }
            }

//             Calling the composable function
//             to display element and its contents
//            MainContent()

        }
    }

//    private fun getMyData(){
//        lifecycleScope.launch {
//            val retrofitData =  api.getSuggestedVideos("New","snippet","US","20","date")
//            print(retrofitData)
//        }
//
//
//    }








    ///////




    ////////


}

@Composable
fun Greeting(s: String) {

    Text(text = "Names")
}

@Composable
fun RecyclerItems(names : List<String> = List(1000){"$it"}){
    LazyColumn(modifier = Modifier.padding(vertical = 4.dp)){
        items(items = names){ name->
            ListItem(name = name)
        }
    }
}



@Composable
fun ListItem(name: String) {
    Surface(
        color = MaterialTheme.colors.primary,
        modifier = Modifier.padding(vertical = 4.dp, horizontal = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
        ) {

            Row {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Video Title")
                    Text(
                        text = name, textAlign = TextAlign.Center,style = MaterialTheme.typography.h4.copy(
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                }

                OutlinedButton(onClick = { /*TODO*/
//                    viewModel.testViewmodel()
                }) {
                    Text(text = "Play Video")
                }

            }

        }
    }
}




// Calling this function as content in the above function
@Composable
fun MyContent(){

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {

        // Fetching the Local Context
        val mContext = LocalContext.current

        // Declaring a string value
        // that stores raw video url
        val mVideoUrl = "https://cdn.videvo.net/videvo_files/video/free/2020-05/large_watermarked/3d_ocean_1590675653_preview.mp4"


        // Declaring ExoPlayer
        val mExoPlayer = remember(mContext) {
            ExoPlayer.Builder(mContext).build().apply {
                val dataSourceFactory = DefaultDataSource.Factory(mContext)
                val source = ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(
                    MediaItem.fromUri(Uri.parse(mVideoUrl)))
                prepare(source)
            }
//            youtubePlayer
        }
//
        // Implementing ExoPlayer
        AndroidView(factory = { context ->
            PlayerView(context).apply {
                player = mExoPlayer
            }
        })





    }
}

@Preview
@Composable
fun DefaultPreview(){
    YouTubeAndroidTheme {
//        ListItem(name = "1")
        RecyclerItems()
    }
}


